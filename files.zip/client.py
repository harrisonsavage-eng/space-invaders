"""
client.py - Space Invaders Co-op Client
Run TWO instances of this file (on the same or different machines on LAN).
First instance = Player 1, Second = Player 2.

Requirements:
    pip install pygame

Usage:
    1. Start server.py first
    2. Run: python client.py
    3. Enter the server IP when prompted (or press Enter for localhost)
"""

import pygame
import sys
import socket
import threading
import json
import random
import math
import time
import os

# ─────────────────────────────────────────────
# CONSTANTS
# ─────────────────────────────────────────────
W, H = 1280, 720
HALF_W = W // 2
FPS = 60

# Colors
BLACK   = (0,   0,   0)
WHITE   = (255, 255, 255)
GREEN   = (0,   255, 100)
RED     = (255, 60,  60)
YELLOW  = (255, 215, 0)
CYAN    = (0,   200, 255)
PURPLE  = (150, 0,   200)
GREY    = (80,  80,  80)
ORANGE  = (255, 150, 50)
PINK    = (255, 100, 200)
DKBLUE  = (10,  10,  40)

# Player zone offsets (so each player draws in their half)
PLAYER_OFFSETS = {1: 0, 2: HALF_W}

# Game settings
ALIEN_ROWS     = 3
ALIENS_PER_ROW = 8
BARRIER_COUNT  = 4
SHIP_SPEED     = 5
BULLET_SPEED   = 9
ALIEN_BULLET_SPEED = 4
ALIEN_DROP     = 18
BARRIER_SEGS   = 12   # segments per barrier row

DATA_FILE = "game_data.json"

# ─────────────────────────────────────────────
# SKIN RENDERER
# ─────────────────────────────────────────────

def draw_ship(surface, style, color, x, y, size=32):
    """Draw a pixel-art style ship based on skin style."""
    c = color
    dim = tuple(max(0, v - 80) for v in c)   # darker shade
    hi  = tuple(min(255, v + 80) for v in c) # highlight

    cx = x
    cy = y

    if style == "classic":
        # Classic triangular ship
        pts = [(cx, cy-size//2), (cx-size//2, cy+size//2), (cx+size//2, cy+size//2)]
        pygame.draw.polygon(surface, c, pts)
        pygame.draw.rect(surface, hi, (cx-4, cy, 8, size//3))
        pygame.draw.circle(surface, WHITE, (cx, cy+2), 5)

    elif style == "retro":
        pts = [(cx, cy-size//2), (cx-size//2, cy+size//2), (cx+size//2, cy+size//2)]
        pygame.draw.polygon(surface, c, pts)
        pygame.draw.polygon(surface, hi, [(cx, cy-size//3), (cx-8, cy+size//4), (cx+8, cy+size//4)])
        pygame.draw.rect(surface, (200,180,0), (cx-2, cy+2, 4, 10))

    elif style == "neon":
        pts = [(cx, cy-size//2), (cx-size//3, cy+size//2), (cx+size//3, cy+size//2)]
        pygame.draw.polygon(surface, c, pts)
        pygame.draw.polygon(surface, hi, pts, 2)
        pygame.draw.line(surface, hi, (cx, cy-size//2), (cx, cy+size//2), 2)
        pygame.draw.circle(surface, PINK, (cx, cy+2), 4, 1)

    elif style == "stealth":
        pts = [(cx, cy-size//2), (cx-size//2, cy+size//3), (cx-size//4, cy+size//2),
               (cx+size//4, cy+size//2), (cx+size//2, cy+size//3)]
        pygame.draw.polygon(surface, c, pts)
        # tiny stars
        for _ in range(5):
            sx = cx + random.randint(-10, 10)
            sy = cy + random.randint(-10, 10)
            pygame.draw.circle(surface, WHITE, (sx, sy), 1)

    elif style == "plasma":
        pts = [(cx, cy-size//2), (cx-size//2, cy+size//2), (cx+size//2, cy+size//2)]
        pygame.draw.polygon(surface, c, pts)
        # Plasma trail (dots)
        for i in range(3):
            pygame.draw.circle(surface, (255, 100+i*30, 0), (cx, cy+size//2+i*5), 3-i)

    elif style == "organic":
        # Organic blob-like ship
        pts = [(cx, cy-size//2), (cx-size//2, cy+size//4), (cx-size//4, cy+size//2),
               (cx+size//4, cy+size//2), (cx+size//2, cy+size//4)]
        pygame.draw.polygon(surface, c, pts)
        pygame.draw.circle(surface, (200, 0, 255), (cx-8, cy), 4)
        pygame.draw.circle(surface, (200, 0, 255), (cx+8, cy), 4)

    elif style == "8bit":
        # Big chunky pixels
        pixel = size // 6
        layout = [
            "  X  ",
            " XXX ",
            "XXXXX",
            " XXX ",
        ]
        for row, line in enumerate(layout):
            for col, ch in enumerate(line):
                if ch == 'X':
                    rx = cx - len(line)//2 * pixel + col * pixel
                    ry = cy - size//3 + row * pixel
                    pygame.draw.rect(surface, c, (rx, ry, pixel, pixel))

    elif style == "crystal":
        pts = [(cx, cy-size//2), (cx-size//3, cy), (cx-size//4, cy+size//2),
               (cx+size//4, cy+size//2), (cx+size//3, cy)]
        pygame.draw.polygon(surface, (*c, 180), pts)
        pygame.draw.polygon(surface, hi, pts, 2)
        pygame.draw.line(surface, WHITE, (cx-size//4, cy), (cx+size//4, cy), 1)

    elif style == "nebula":
        pts = [(cx, cy-size//2), (cx-size//2, cy+size//2), (cx+size//2, cy+size//2)]
        pygame.draw.polygon(surface, c, pts)
        # Gradient-ish effect with circles
        for i in range(3):
            alpha_c = tuple(min(255, v + i*30) for v in c)
            pygame.draw.circle(surface, alpha_c, (cx, cy+i*5), size//4 - i*3, 1)

    elif style == "dark":
        pts = [(cx, cy-size//2), (cx-size//2, cy+size//2), (cx+size//2, cy+size//2)]
        pygame.draw.polygon(surface, c, pts)
        # Red "eyes"
        pygame.draw.circle(surface, RED, (cx-6, cy+2), 4)
        pygame.draw.circle(surface, RED, (cx+6, cy+2), 4)
        pygame.draw.circle(surface, (255, 150, 0), (cx-6, cy+2), 2)
        pygame.draw.circle(surface, (255, 150, 0), (cx+6, cy+2), 2)

    else:
        pts = [(cx, cy-size//2), (cx-size//2, cy+size//2), (cx+size//2, cy+size//2)]
        pygame.draw.polygon(surface, c, pts)


# ─────────────────────────────────────────────
# GAME DATA MANAGER
# ─────────────────────────────────────────────

class DataManager:
    def __init__(self, player_id):
        self.player_id = player_id
        self.data = self._load()
        self.pkey = f"player{player_id}"

    def _load(self):
        if os.path.exists(DATA_FILE):
            with open(DATA_FILE) as f:
                return json.load(f)
        return {}

    def save(self):
        with open(DATA_FILE, 'w') as f:
            json.dump(self.data, f, indent=2)

    def player(self):
        return self.data.get(self.pkey, {})

    def add_coins(self, amount):
        self.data[self.pkey]["coins"] += amount
        self.save()

    def add_xp(self, amount):
        p = self.data[self.pkey]
        p["xp"] = p.get("xp", 0) + amount
        # Check battle pass tiers
        bp = self.data["battle_pass"]["tiers"]
        current_tier = p.get("battle_pass_tier", 0)
        for tier_data in bp:
            t = tier_data["tier"]
            if t > current_tier and p["xp"] >= tier_data["xp_required"]:
                p["battle_pass_tier"] = t
                self._grant_reward(tier_data)
        self.save()

    def _grant_reward(self, tier_data):
        p = self.data[self.pkey]
        rtype = tier_data["reward_type"]
        reward = tier_data["reward"]
        if rtype == "skin" and reward not in p["owned_skins"]:
            p["owned_skins"].append(reward)
        elif rtype == "coins":
            p["coins"] += reward
        elif rtype == "laser" and reward not in p.get("owned_lasers", []):
            p.setdefault("owned_lasers", []).append(reward)

    def buy_skin(self, skin_id):
        skin = self.data["skins"].get(skin_id)
        p = self.data[self.pkey]
        if not skin:
            return False, "Skin not found"
        if skin_id in p["owned_skins"]:
            return False, "Already owned"
        if skin.get("bp_tier"):
            return False, "Battle Pass reward only"
        if p["coins"] < skin["cost"]:
            return False, "Not enough coins"
        p["coins"] -= skin["cost"]
        p["owned_skins"].append(skin_id)
        self.save()
        return True, "Purchased!"

    def equip_skin(self, skin_id):
        p = self.data[self.pkey]
        if skin_id in p["owned_skins"]:
            p["active_skin"] = skin_id
            self.save()
            return True
        return False

    def get_skin_info(self):
        p = self.player()
        sid = p.get("active_skin", "classic")
        skin = self.data["skins"].get(sid, self.data["skins"]["classic"])
        return skin

    def get_laser_color(self):
        p = self.player()
        lid = p.get("laser_color", "green")
        return self.data["laser_colors"].get(lid, self.data["laser_colors"]["green"])


# ─────────────────────────────────────────────
# NETWORK CLIENT
# ─────────────────────────────────────────────

class NetworkClient:
    def __init__(self, host, port=5555):
        self.host = host
        self.port = port
        self.player_id = None
        self.sock = None
        self.connected = False
        self.server_state = {}
        self.message_queue = []
        self._lock = threading.Lock()
        self._buf = ""

    def connect(self):
        try:
            self.sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            self.sock.connect((self.host, self.port))
            self.connected = True
            t = threading.Thread(target=self._recv_loop, daemon=True)
            t.start()
            return True
        except Exception as e:
            print(f"[Client] Connection failed: {e}")
            return False

    def _recv_loop(self):
        while self.connected:
            try:
                data = self.sock.recv(4096).decode()
                if not data:
                    break
                self._buf += data
                while '\n' in self._buf:
                    line, self._buf = self._buf.split('\n', 1)
                    if line.strip():
                        try:
                            msg = json.loads(line)
                            with self._lock:
                                self.message_queue.append(msg)
                        except Exception:
                            pass
            except Exception:
                break
        self.connected = False

    def send(self, msg):
        if self.connected:
            try:
                self.sock.sendall((json.dumps(msg) + '\n').encode())
            except Exception:
                pass

    def get_messages(self):
        with self._lock:
            msgs = self.message_queue[:]
            self.message_queue.clear()
        return msgs


# ─────────────────────────────────────────────
# STARFIELD
# ─────────────────────────────────────────────

class Starfield:
    def __init__(self):
        self.stars = [
            (random.randint(0, W), random.randint(0, H), random.uniform(0.3, 2.0))
            for _ in range(200)
        ]
        self.scroll = 0
        # Planets per level theme
        self.planets = [
            {"color": (80, 120, 200), "ring": False, "name": "Earth-like"},
            {"color": (200, 140, 60),  "ring": True,  "name": "Saturn-like"},
            {"color": (200, 60, 60),   "ring": False, "name": "Mars-like"},
            {"color": (60, 200, 180),  "ring": False, "name": "Ice Giant"},
            {"color": (220, 200, 100), "ring": True,  "name": "Gas Giant"},
        ]

    def update(self):
        self.scroll = (self.scroll + 0.3) % H

    def draw(self, surface, level):
        surface.fill(DKBLUE)
        # Draw stars
        for (sx, sy, speed) in self.stars:
            y = int((sy + self.scroll * speed) % H)
            brightness = int(150 + 105 * speed / 2.0)
            col = (brightness, brightness, brightness)
            r = 1 if speed < 1.0 else 2
            pygame.draw.circle(surface, col, (sx, y), r)

        # Draw planet (changes every 5 levels)
        planet_idx = ((level - 1) // 5) % len(self.planets)
        planet = self.planets[planet_idx]
        px, py = W // 2, H // 5
        pr = 55
        pygame.draw.circle(surface, planet["color"], (px, py), pr)
        # Atmosphere glow
        atm = tuple(min(255, v + 30) for v in planet["color"])
        pygame.draw.circle(surface, atm, (px, py), pr, 4)
        # Ring
        if planet["ring"]:
            ring_surf = pygame.Surface((pr*3, pr), pygame.SRCALPHA)
            pygame.draw.ellipse(ring_surf, (*planet["color"], 120), (0, 0, pr*3, pr), 6)
            surface.blit(ring_surf, (px - pr*3//2, py - pr//2))
        # Highlight
        pygame.draw.circle(surface, WHITE, (px - pr//4, py - pr//4), pr//5)


# ─────────────────────────────────────────────
# BARRIER
# ─────────────────────────────────────────────

class Barrier:
    SEG_SIZE = 8
    COLS = 8
    ROWS = 4

    def __init__(self, bid, cx, y, style="classic_bricks"):
        self.id = bid
        self.style = style
        self.segments = {}  # (col, row) -> health (1-3)
        for row in range(self.ROWS):
            for col in range(self.COLS):
                self.segments[(col, row)] = 3

    def draw(self, surface, offset_x):
        for (col, row), hp in self.segments.items():
            if hp <= 0:
                continue
            x = self.cx + (col - self.COLS//2) * self.SEG_SIZE + offset_x
            y = self.y + row * self.SEG_SIZE

            if self.style == "metal_plates":
                base = (100, 100, 120)
                colors = [base, (130, 130, 150), (160, 160, 180)]
            elif self.style == "energy_field":
                t = pygame.time.get_ticks() / 1000
                g = int(128 + 127 * math.sin(t + col * 0.3))
                base = (0, g, 200)
                colors = [base, (0, 200, 255), (100, 255, 255)]
            else:  # classic_bricks
                colors = [(0, 160, 0), (0, 200, 0), (0, 255, 0)]

            col_idx = min(hp - 1, 2)
            pygame.draw.rect(surface, colors[col_idx], (x, y, self.SEG_SIZE-1, self.SEG_SIZE-1))

    def hit(self, x, y, offset_x):
        """Return segment key if bullet hits, else None."""
        for (col, row), hp in list(self.segments.items()):
            if hp <= 0:
                continue
            bx = self.cx + (col - self.COLS//2) * self.SEG_SIZE + offset_x
            by = self.y + row * self.SEG_SIZE
            if bx <= x <= bx + self.SEG_SIZE and by <= y <= by + self.SEG_SIZE:
                self.segments[(col, row)] -= 1
                if self.segments[(col, row)] <= 0:
                    del self.segments[(col, row)]
                return (col, row)
        return None

    def to_dict(self):
        return {
            "id": self.id,
            "cx": self.cx,
            "y": self.y,
            "segments": [{"col": c, "row": r, "hp": hp} for (c,r), hp in self.segments.items()]
        }


# ─────────────────────────────────────────────
# GAME ENTITIES
# ─────────────────────────────────────────────

class Player:
    def __init__(self, player_id, data_mgr, zone_width):
        self.id = player_id
        self.dmgr = data_mgr
        self.zone_w = zone_width
        self.x = zone_width // 2
        self.y = H - 80
        self.speed = SHIP_SPEED
        self.bullets = []
        self.shoot_cooldown = 0
        self.lives = 3
        self.invincible = 0
        self.skin = data_mgr.get_skin_info()
        self.laser_info = data_mgr.get_laser_color()

    def update(self, keys, left_key, right_key, shoot_key):
        if keys[left_key] and self.x > 30:
            self.x -= self.speed
        if keys[right_key] and self.x < self.zone_w - 30:
            self.x += self.speed
        if keys[shoot_key] and self.shoot_cooldown <= 0:
            self.bullets.append({"x": self.x, "y": self.y - 20, "dy": -BULLET_SPEED})
            self.shoot_cooldown = 15

        if self.shoot_cooldown > 0:
            self.shoot_cooldown -= 1
        if self.invincible > 0:
            self.invincible -= 1

        self.bullets = [b for b in self.bullets if b["y"] > 0]
        for b in self.bullets:
            b["y"] += b["dy"]

    def draw(self, surface, offset_x):
        # Draw bullets
        for b in self.bullets:
            color = self.laser_info.get("rgb") or self._rainbow_color()
            pygame.draw.rect(surface, color or GREEN, (b["x"] + offset_x - 2, b["y"], 4, 12))

        # Draw ship (flash when invincible)
        if self.invincible == 0 or (self.invincible // 5) % 2 == 0:
            draw_ship(surface, self.skin["style"], tuple(self.skin["colors"]),
                      self.x + offset_x, self.y)

        # Draw lives
        for i in range(self.lives):
            draw_ship(surface, self.skin["style"], tuple(self.skin["colors"]),
                      20 + i * 28 + offset_x, H - 20, size=14)

    def _rainbow_color(self):
        t = pygame.time.get_ticks() / 200
        r = int(127 + 127 * math.sin(t))
        g = int(127 + 127 * math.sin(t + 2))
        b = int(127 + 127 * math.sin(t + 4))
        return (r, g, b)

    def hit(self):
        if self.invincible <= 0:
            self.lives -= 1
            self.invincible = 90


class Alien:
    TYPES = [
        {"color": (0, 255, 100),   "points": 100, "coins": 10, "speed_mult": 1.0},
        {"color": (255, 200, 0),   "points": 200, "coins": 20, "speed_mult": 1.3},
        {"color": (200, 50, 255),  "points": 300, "coins": 30, "speed_mult": 1.6},
    ]

    def __init__(self, aid, row, col, level):
        self.id = aid
        atype = self.TYPES[min(row, len(self.TYPES)-1)]
        self.color = atype["color"]
        self.points = atype["points"]
        self.coins = atype["coins"]
        spacing = (HALF_W - 60) // max(ALIENS_PER_ROW, 1)
        self.x = 40 + col * spacing
        self.y = 80 + row * 55
        self.base_speed = 0.6 + level * 0.05
        self.dx = self.base_speed * atype["speed_mult"]
        self.shoot_timer = random.randint(60, 300)
        self.anim = 0

    def update(self, aliens, zone_width):
        self.x += self.dx
        self.anim = (self.anim + 1) % 60
        # Bounce
        if any(a.x > zone_width - 30 for a in aliens) or any(a.x < 20 for a in aliens):
            for a in aliens:
                a.dx = -a.dx
                a.y += ALIEN_DROP

    def draw(self, surface, offset_x):
        x = self.x + offset_x
        y = self.y
        # Animate legs
        leg_offset = 3 if (self.anim // 10) % 2 == 0 else -3
        pygame.draw.rect(surface, self.color, (x-12, y-8, 24, 16))
        pygame.draw.circle(surface, self.color, (x, y-12), 10)
        pygame.draw.circle(surface, BLACK, (x-4, y-13), 3)
        pygame.draw.circle(surface, BLACK, (x+4, y-13), 3)
        pygame.draw.circle(surface, WHITE, (x-4, y-13), 1)
        pygame.draw.circle(surface, WHITE, (x+4, y-13), 1)
        # Legs
        pygame.draw.line(surface, self.color, (x-12, y+5), (x-18, y+10+leg_offset), 2)
        pygame.draw.line(surface, self.color, (x+12, y+5), (x+18, y+10+leg_offset), 2)
        pygame.draw.line(surface, self.color, (x-6, y+8), (x-10, y+14-leg_offset), 2)
        pygame.draw.line(surface, self.color, (x+6, y+8), (x+10, y+14-leg_offset), 2)


class Boss:
    def __init__(self, level):
        self.x = HALF_W // 2
        self.y = 60
        self.hp = 20 + level * 5
        self.max_hp = self.hp
        self.dx = 1.5 + level * 0.1
        self.shoot_timer = 0
        self.anim = 0
        self.points = 2000 + level * 200
        self.coins = 100

    def update(self, zone_width):
        self.x += self.dx
        if self.x > zone_width - 50 or self.x < 50:
            self.dx = -self.dx
        self.anim = (self.anim + 1) % 60

    def draw(self, surface, offset_x):
        x = self.x + offset_x
        y = self.y
        t = self.anim / 60
        # Pulsing body
        pulse = int(5 * math.sin(t * math.pi * 2))
        pygame.draw.ellipse(surface, (180, 0, 0), (x-40, y-20+pulse, 80, 40))
        pygame.draw.ellipse(surface, (255, 50, 50), (x-28, y-12+pulse, 56, 28))
        # Eye
        pygame.draw.circle(surface, YELLOW, (x, y+pulse), 12)
        pygame.draw.circle(surface, RED, (x, y+pulse), 6)
        pygame.draw.circle(surface, BLACK, (x, y+pulse), 3)
        # HP bar
        bar_w = 80
        bar_x = x - 40
        bar_y = y + 30
        pygame.draw.rect(surface, GREY, (bar_x, bar_y, bar_w, 8))
        hp_ratio = max(0, self.hp / self.max_hp)
        hp_color = GREEN if hp_ratio > 0.5 else YELLOW if hp_ratio > 0.25 else RED
        pygame.draw.rect(surface, hp_color, (bar_x, bar_y, int(bar_w * hp_ratio), 8))
        pygame.draw.rect(surface, WHITE, (bar_x, bar_y, bar_w, 8), 1)
        # Label
        font = pygame.font.SysFont("monospace", 11)
        surface.blit(font.render("BOSS", True, RED), (x-15, bar_y+10))


# ─────────────────────────────────────────────
# SCREEN: SHOP
# ─────────────────────────────────────────────

class ShopScreen:
    def __init__(self, data_mgr, font, small_font):
        self.dmgr = data_mgr
        self.font = font
        self.small_font = small_font
        self.selected = 0
        self.message = ""
        self.msg_timer = 0
        self.skins = list(data_mgr.data["skins"].items())

    def handle_event(self, event):
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_LEFT:
                self.selected = (self.selected - 1) % len(self.skins)
            elif event.key == pygame.K_RIGHT:
                self.selected = (self.selected + 1) % len(self.skins)
            elif event.key == pygame.K_RETURN:
                sid, sdata = self.skins[self.selected]
                p = self.dmgr.player()
                if sid in p["owned_skins"]:
                    self.dmgr.equip_skin(sid)
                    self.message = f"Equipped {sdata['name']}!"
                else:
                    ok, msg = self.dmgr.buy_skin(sid)
                    self.message = msg
                self.msg_timer = 90
            elif event.key == pygame.K_ESCAPE:
                return "menu"
        return None

    def update(self):
        if self.msg_timer > 0:
            self.msg_timer -= 1

    def draw(self, surface, starfield, level):
        starfield.draw(surface, level)
        overlay = pygame.Surface((W, H), pygame.SRCALPHA)
        overlay.fill((0, 0, 0, 160))
        surface.blit(overlay, (0, 0))

        # Title
        title = self.font.render("⬡  SHIP SHOP  ⬡", True, YELLOW)
        surface.blit(title, (W//2 - title.get_width()//2, 20))

        p = self.dmgr.player()
        coin_text = self.small_font.render(f"Coins: {p['coins']}", True, YELLOW)
        surface.blit(coin_text, (W - 160, 20))

        # Skin grid
        cols = 5
        per_skin_w = W // cols
        per_skin_h = 170
        start_y = 80

        for i, (sid, sdata) in enumerate(self.skins):
            col = i % cols
            row = i // cols
            sx = col * per_skin_w + per_skin_w//2
            sy = start_y + row * per_skin_h + 60

            # Highlight selected
            if i == self.selected:
                pygame.draw.rect(surface, CYAN,
                    (col*per_skin_w + 5, start_y + row*per_skin_h + 5, per_skin_w-10, per_skin_h-10), 2)

            # Draw preview ship
            draw_ship(surface, sdata["style"], tuple(sdata["colors"]), sx, sy, size=28)

            # Name
            owned = sid in p["owned_skins"]
            equipped = p.get("active_skin") == sid
            name_col = GREEN if equipped else (YELLOW if owned else WHITE)
            name_surf = self.small_font.render(sdata["name"], True, name_col)
            surface.blit(name_surf, (sx - name_surf.get_width()//2, sy + 36))

            # Cost / status
            if equipped:
                status = "EQUIPPED"
                scol = CYAN
            elif owned:
                status = "OWNED (ENTER)"
                scol = GREEN
            elif sdata.get("bp_tier"):
                status = f"BP Tier {sdata['bp_tier']}"
                scol = PURPLE
            else:
                status = f"{sdata['cost']} coins"
                scol = YELLOW
            s_surf = self.small_font.render(status, True, scol)
            surface.blit(s_surf, (sx - s_surf.get_width()//2, sy + 54))

        # Message
        if self.msg_timer > 0:
            msg_surf = self.font.render(self.message, True, CYAN)
            surface.blit(msg_surf, (W//2 - msg_surf.get_width()//2, H - 80))

        # Instructions
        inst = self.small_font.render("← → Navigate  |  ENTER: Buy/Equip  |  ESC: Back", True, GREY)
        surface.blit(inst, (W//2 - inst.get_width()//2, H - 40))


# ─────────────────────────────────────────────
# SCREEN: BATTLE PASS
# ─────────────────────────────────────────────

class BattlePassScreen:
    def __init__(self, data_mgr, font, small_font):
        self.dmgr = data_mgr
        self.font = font
        self.small_font = small_font

    def handle_event(self, event):
        if event.type == pygame.KEYDOWN and event.key == pygame.K_ESCAPE:
            return "menu"
        return None

    def draw(self, surface, starfield, level):
        starfield.draw(surface, level)
        overlay = pygame.Surface((W, H), pygame.SRCALPHA)
        overlay.fill((0, 0, 0, 160))
        surface.blit(overlay, (0, 0))

        title = self.font.render("★  BATTLE PASS  ★", True, YELLOW)
        surface.blit(title, (W//2 - title.get_width()//2, 20))

        p = self.dmgr.player()
        current_tier = p.get("battle_pass_tier", 0)
        current_xp = p.get("xp", 0)

        xp_text = self.small_font.render(f"XP: {current_xp}  |  Tier: {current_tier}/10", True, CYAN)
        surface.blit(xp_text, (W//2 - xp_text.get_width()//2, 60))

        tiers = self.dmgr.data["battle_pass"]["tiers"]
        tier_w = (W - 80) // len(tiers)
        for i, tier in enumerate(tiers):
            x = 40 + i * tier_w + tier_w//2
            y = H // 2

            unlocked = current_tier >= tier["tier"]
            color = YELLOW if unlocked else GREY

            # Tier box
            box_col = (50, 50, 0) if unlocked else (30, 30, 30)
            pygame.draw.rect(surface, box_col, (x-30, y-60, 60, 120))
            pygame.draw.rect(surface, color, (x-30, y-60, 60, 120), 2)

            t_num = self.small_font.render(f"T{tier['tier']}", True, color)
            surface.blit(t_num, (x - t_num.get_width()//2, y-55))

            label_surf = self.small_font.render(tier["label"][:10], True, color)
            surface.blit(label_surf, (x - label_surf.get_width()//2, y-30))

            # XP bar
            if i < len(tiers) - 1:
                next_xp = tiers[i+1]["xp_required"]
                curr_xp_req = tier["xp_required"]
                ratio = min(1.0, max(0, (current_xp - curr_xp_req) / max(1, next_xp - curr_xp_req)))
                pygame.draw.rect(surface, GREY, (x+30, y, tier_w-10, 8))
                pygame.draw.rect(surface, YELLOW, (x+30, y, int((tier_w-10)*ratio), 8))

            # Reward icon
            rtype = tier["reward_type"]
            icon_col = CYAN if rtype == "skin" else YELLOW if rtype == "coins" else ORANGE
            pygame.draw.circle(surface, icon_col, (x, y+30), 10)
            r_label = self.small_font.render(rtype[0].upper(), True, BLACK)
            surface.blit(r_label, (x-4, y+23))

        inst = self.small_font.render("ESC: Back", True, GREY)
        surface.blit(inst, (W//2 - inst.get_width()//2, H - 40))


# ─────────────────────────────────────────────
# MAIN GAME
# ─────────────────────────────────────────────

class Game:
    def __init__(self, player_id, net):
        self.player_id = player_id
        self.net = net
        self.dmgr = DataManager(player_id)
        pygame.init()
        self.screen = pygame.display.set_mode((W, H))
        pygame.display.set_caption(f"Space Invaders Co-op — Player {player_id}")
        self.clock = pygame.time.Clock()
        self.font = pygame.font.SysFont("monospace", 22, bold=True)
        self.small_font = pygame.font.SysFont("monospace", 14)
        self.big_font = pygame.font.SysFont("monospace", 42, bold=True)

        self.starfield = Starfield()
        self.state = "waiting"  # waiting, menu, playing, shop, battlepass, game_over
        self.level = 1
        self.game_surf = pygame.Surface((HALF_W, H))

        self.player = None
        self.aliens = []
        self.barriers = []
        self.alien_bullets = []
        self.boss = None
        self.boss_bullets = []
        self.score = 0
        self.chat_msgs = []
        self.chat_input = ""
        self.chat_active = False
        self.other_player_state = {}

        self.shop_screen = ShopScreen(self.dmgr, self.font, self.small_font)
        self.bp_screen = BattlePassScreen(self.dmgr, self.font, self.small_font)

        # If solo (no network), start directly
        if not net:
            self.state = "menu"

    def init_level(self):
        """Initialize aliens and barriers for this level."""
        self.aliens.clear()
        self.alien_bullets.clear()
        self.boss = None
        self.boss_bullets.clear()
        aid = 0
        for row in range(ALIEN_ROWS):
            for col in range(ALIENS_PER_ROW):
                self.aliens.append(Alien(aid, row, col, self.level))
                aid += 1

        # Barriers
        self.barriers.clear()
        bw = HALF_W // (BARRIER_COUNT + 1)
        for i in range(BARRIER_COUNT):
            b = Barrier(i, 0, 0, self.dmgr.player().get("shield_skin", "classic_bricks"))
            b.cx = bw * (i + 1)
            b.y = H - 160
            self.barriers.append(b)

        # Boss on every 10th level
        if self.level % 10 == 0:
            self.boss = Boss(self.level)

    def init_player(self):
        self.player = Player(self.player_id, self.dmgr, HALF_W)

    def handle_network(self):
        msgs = self.net.get_messages() if self.net else []
        for msg in msgs:
            mtype = msg.get("type")
            if mtype == "welcome":
                self.player_id = msg.get("player_id", self.player_id)
                print(f"[Game] Assigned Player ID: {self.player_id}")
            elif mtype == "start_game":
                self.state = "menu"
            elif mtype == "state_sync":
                data = msg.get("data", {})
                self.other_player_state = data.get("players", {}).get(
                    str(2 if self.player_id == 1 else 1), {}
                )
                # Sync chat
                self.chat_msgs = data.get("chat", [])
            elif mtype == "player_left":
                pass  # Could show disconnect notice

    def send_player_state(self):
        if self.net and self.player:
            self.net.send({
                "type": "player_update",
                "data": {
                    "x": self.player.x,
                    "y": self.player.y,
                    "skin": self.dmgr.get_skin_info(),
                    "lives": self.player.lives,
                    "score": self.score
                }
            })

    def handle_menu_events(self, event):
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_RETURN:
                self.init_level()
                self.init_player()
                self.state = "playing"
            elif event.key == pygame.K_s:
                self.state = "shop"
            elif event.key == pygame.K_b:
                self.state = "battlepass"

    def handle_game_events(self, event):
        if event.type == pygame.KEYDOWN:
            if self.chat_active:
                if event.key == pygame.K_RETURN:
                    if self.chat_input.strip():
                        if self.net:
                            self.net.send({"type": "chat", "text": self.chat_input.strip()})
                        else:
                            self.chat_msgs.append({
                                "player": self.player_id,
                                "text": self.chat_input.strip(),
                                "time": time.time()
                            })
                    self.chat_input = ""
                    self.chat_active = False
                elif event.key == pygame.K_ESCAPE:
                    self.chat_input = ""
                    self.chat_active = False
                elif event.key == pygame.K_BACKSPACE:
                    self.chat_input = self.chat_input[:-1]
                else:
                    if len(self.chat_input) < 60:
                        self.chat_input += event.unicode
            else:
                if event.key == pygame.K_t:
                    self.chat_active = True

    def update_game(self):
        keys = pygame.key.get_pressed()
        # Player 1: WASD + Space | Player 2: Arrow + RShift
        if self.player_id == 1:
            if not self.chat_active:
                self.player.update(keys, pygame.K_a, pygame.K_d, pygame.K_SPACE)
        else:
            if not self.chat_active:
                self.player.update(keys, pygame.K_LEFT, pygame.K_RIGHT, pygame.K_RSHIFT)

        # Update aliens (only player 1 authoritative in co-op)
        if self.aliens:
            for alien in self.aliens:
                alien.update(self.aliens, HALF_W)
                # Alien shooting
                alien.shoot_timer -= 1
                if alien.shoot_timer <= 0:
                    alien.shoot_timer = random.randint(80, 400)
                    self.alien_bullets.append({"x": alien.x, "y": alien.y, "dy": ALIEN_BULLET_SPEED})

        # Update boss
        if self.boss:
            self.boss.update(HALF_W)
            self.boss.shoot_timer -= 1
            if self.boss.shoot_timer <= 0:
                self.boss.shoot_timer = 40
                # Triple shot
                for angle in [-15, 0, 15]:
                    rad = math.radians(90 + angle)
                    self.boss_bullets.append({
                        "x": self.boss.x, "y": self.boss.y + 30,
                        "dx": math.cos(rad) * 3, "dy": math.sin(rad) * 3
                    })

        # Move alien bullets
        for b in self.alien_bullets:
            b["y"] += b["dy"]
        self.alien_bullets = [b for b in self.alien_bullets if b["y"] < H]

        for b in self.boss_bullets:
            b["x"] += b["dx"]
            b["y"] += b["dy"]
        self.boss_bullets = [b for b in self.boss_bullets if 0 < b["y"] < H]

        # Collision: player bullets vs aliens
        for bullet in list(self.player.bullets):
            for alien in list(self.aliens):
                if abs(bullet["x"] - alien.x) < 16 and abs(bullet["y"] - alien.y) < 16:
                    self.player.bullets.remove(bullet)
                    self.aliens.remove(alien)
                    self.score += alien.points
                    self.dmgr.add_coins(alien.coins)
                    self.dmgr.add_xp(alien.points // 10)
                    if self.net:
                        self.net.send({"type": "alien_killed", "alien_id": alien.id,
                                       "coins": alien.coins, "points": alien.points})
                    break

        # Collision: player bullets vs boss
        if self.boss:
            for bullet in list(self.player.bullets):
                if abs(bullet["x"] - self.boss.x) < 45 and abs(bullet["y"] - self.boss.y) < 25:
                    self.player.bullets.remove(bullet)
                    self.boss.hp -= 1
                    if self.net:
                        self.net.send({"type": "boss_hit", "dmg": 1})
                    if self.boss.hp <= 0:
                        self.score += self.boss.points
                        self.dmgr.add_coins(self.boss.coins)
                        self.boss = None
                    break

        # Collision: alien bullets vs player
        for b in list(self.alien_bullets):
            if (abs(b["x"] - self.player.x) < 20 and abs(b["y"] - self.player.y) < 20):
                self.alien_bullets.remove(b)
                self.player.hit()
                break

        for b in list(self.boss_bullets):
            if (abs(b["x"] - self.player.x) < 20 and abs(b["y"] - self.player.y) < 20):
                self.boss_bullets.remove(b)
                self.player.hit()
                break

        # Collision: bullets vs barriers
        for b in list(self.player.bullets):
            for bar in self.barriers:
                if bar.hit(b["x"], b["y"], 0):
                    if b in self.player.bullets:
                        self.player.bullets.remove(b)
                    break
        for b in list(self.alien_bullets):
            for bar in self.barriers:
                if bar.hit(b["x"], b["y"], 0):
                    self.alien_bullets.remove(b)
                    break

        # Level complete
        if not self.aliens and not self.boss:
            self.level += 1
            self.init_level()
            if self.net:
                self.net.send({"type": "level_up", "level": self.level})

        # Aliens reach bottom
        if self.aliens and max(a.y for a in self.aliens) > H - 100:
            self.player.lives = 0

        # Game over
        if self.player.lives <= 0:
            self.state = "game_over"

        # Sync to server
        self.send_player_state()

    def draw_game(self):
        self.starfield.update()
        self.starfield.draw(self.screen, self.level)

        offset = PLAYER_OFFSETS.get(self.player_id, 0)

        # Draw divider
        pygame.draw.line(self.screen, GREY, (HALF_W, 0), (HALF_W, H), 1)

        # Labels
        p1_label = self.small_font.render("PLAYER 1", True, GREEN)
        p2_label = self.small_font.render("PLAYER 2", True, CYAN)
        self.screen.blit(p1_label, (10, 10))
        self.screen.blit(p2_label, (HALF_W + 10, 10))

        # Score / level / coins on our side
        score_surf = self.small_font.render(f"Score: {self.score}", True, WHITE)
        self.screen.blit(score_surf, (offset + 10, 30))
        lvl_surf = self.small_font.render(f"Level: {self.level}", True, WHITE)
        self.screen.blit(lvl_surf, (offset + 10, 46))
        p = self.dmgr.player()
        coins_surf = self.small_font.render(f"Coins: {p['coins']}", True, YELLOW)
        self.screen.blit(coins_surf, (offset + 10, 62))
        xp_surf = self.small_font.render(f"XP: {p['xp']}  BP T{p['battle_pass_tier']}", True, PURPLE)
        self.screen.blit(xp_surf, (offset + 10, 78))

        # Draw aliens
        for alien in self.aliens:
            alien.draw(self.screen, offset)

        # Draw boss
        if self.boss:
            self.boss.draw(self.screen, offset)

        # Draw barriers
        for bar in self.barriers:
            bar.draw(self.screen, offset)

        # Draw alien bullets
        for b in self.alien_bullets:
            pygame.draw.rect(self.screen, RED, (b["x"] + offset - 2, b["y"] - 6, 4, 10))
        for b in self.boss_bullets:
            pygame.draw.circle(self.screen, (255, 100, 0), (int(b["x"]) + offset, int(b["y"])), 5)

        # Draw player
        self.player.draw(self.screen, offset)

        # Draw other player (ghost on other side)
        op = self.other_player_state
        if op:
            other_offset = PLAYER_OFFSETS.get(2 if self.player_id == 1 else 1, HALF_W)
            op_skin = op.get("skin", {"style": "classic", "colors": [0, 255, 0]})
            draw_ship(self.screen, op_skin.get("style", "classic"),
                      tuple(op_skin.get("colors", [0, 255, 0])),
                      op.get("x", HALF_W//2) + other_offset,
                      op.get("y", H - 80))
            # Other player score
            op_score = self.small_font.render(f"Score: {op.get('score', 0)}", True, WHITE)
            self.screen.blit(op_score, (other_offset + 10, 30))

        # Chat
        self._draw_chat(offset)

    def _draw_chat(self, offset):
        now = time.time()
        y = H - 110
        for msg in self.chat_msgs[-5:]:
            if now - msg.get("time", 0) < 10:
                pid = msg.get("player", "?")
                col = GREEN if pid == 1 else CYAN
                txt = self.small_font.render(f"P{pid}: {msg['text']}", True, col)
                self.screen.blit(txt, (offset + 5, y))
                y += 16

        if self.chat_active:
            pygame.draw.rect(self.screen, (20, 20, 20), (offset, H - 30, HALF_W, 28))
            pygame.draw.rect(self.screen, CYAN, (offset, H - 30, HALF_W, 28), 1)
            chat_surf = self.small_font.render(f"> {self.chat_input}_", True, WHITE)
            self.screen.blit(chat_surf, (offset + 5, H - 26))
        else:
            hint = self.small_font.render("[T] Chat", True, GREY)
            self.screen.blit(hint, (offset + 5, H - 20))

    def draw_menu(self):
        self.starfield.update()
        self.starfield.draw(self.screen, self.level)
        overlay = pygame.Surface((W, H), pygame.SRCALPHA)
        overlay.fill((0, 0, 0, 140))
        self.screen.blit(overlay, (0, 0))

        title = self.big_font.render("SPACE INVADERS", True, GREEN)
        self.screen.blit(title, (W//2 - title.get_width()//2, 80))
        sub = self.font.render("CO-OP EDITION", True, CYAN)
        self.screen.blit(sub, (W//2 - sub.get_width()//2, 130))

        p = self.dmgr.player()
        skin = self.dmgr.get_skin_info()
        draw_ship(self.screen, skin["style"], tuple(skin["colors"]), W//2, 260, size=40)

        options = [
            ("ENTER", "Start Game"),
            ("S",     "Ship Shop"),
            ("B",     "Battle Pass"),
        ]
        for i, (key, label) in enumerate(options):
            key_surf = self.font.render(f"[{key}]", True, YELLOW)
            lbl_surf = self.font.render(label, True, WHITE)
            y = 340 + i * 46
            self.screen.blit(key_surf, (W//2 - 120, y))
            self.screen.blit(lbl_surf, (W//2 - 30, y))

        info = self.small_font.render(
            f"Player {self.player_id}  |  Coins: {p['coins']}  |  BP Tier: {p.get('battle_pass_tier',0)}  |  XP: {p.get('xp',0)}",
            True, GREY)
        self.screen.blit(info, (W//2 - info.get_width()//2, H - 40))

    def draw_waiting(self):
        self.starfield.update()
        self.starfield.draw(self.screen, 1)
        msg = self.big_font.render("Waiting for Player 2...", True, CYAN)
        self.screen.blit(msg, (W//2 - msg.get_width()//2, H//2 - 30))
        sub = self.small_font.render("Make sure server.py is running!", True, GREY)
        self.screen.blit(sub, (W//2 - sub.get_width()//2, H//2 + 30))

    def draw_game_over(self):
        overlay = pygame.Surface((W, H), pygame.SRCALPHA)
        overlay.fill((0, 0, 0, 180))
        self.screen.blit(overlay, (0, 0))
        go = self.big_font.render("GAME OVER", True, RED)
        self.screen.blit(go, (W//2 - go.get_width()//2, H//2 - 60))
        sc = self.font.render(f"Final Score: {self.score}", True, YELLOW)
        self.screen.blit(sc, (W//2 - sc.get_width()//2, H//2))
        restart = self.small_font.render("Press ENTER to return to menu", True, WHITE)
        self.screen.blit(restart, (W//2 - restart.get_width()//2, H//2 + 60))

    def run(self):
        running = True
        while running:
            self.clock.tick(FPS)
            self.handle_network()

            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    running = False

                if self.state == "menu":
                    self.handle_menu_events(event)
                elif self.state == "playing":
                    self.handle_game_events(event)
                elif self.state == "shop":
                    result = self.shop_screen.handle_event(event)
                    if result == "menu":
                        self.state = "menu"
                elif self.state == "battlepass":
                    result = self.bp_screen.handle_event(event)
                    if result == "menu":
                        self.state = "menu"
                elif self.state == "game_over":
                    if event.type == pygame.KEYDOWN and event.key == pygame.K_RETURN:
                        self.score = 0
                        self.level = 1
                        self.state = "menu"

            # Update
            if self.state == "playing":
                self.update_game()
            elif self.state == "shop":
                self.shop_screen.update()
            self.starfield.update()

            # Draw
            self.screen.fill(BLACK)
            if self.state == "waiting":
                self.draw_waiting()
            elif self.state == "menu":
                self.draw_menu()
            elif self.state == "playing":
                self.draw_game()
            elif self.state == "shop":
                self.shop_screen.draw(self.screen, self.starfield, self.level)
            elif self.state == "battlepass":
                self.bp_screen.draw(self.screen, self.starfield, self.level)
            elif self.state == "game_over":
                self.draw_game()
                self.draw_game_over()

            pygame.display.flip()

        pygame.quit()
        if self.net:
            self.net.sock.close()
        sys.exit()


# ─────────────────────────────────────────────
# ENTRY POINT
# ─────────────────────────────────────────────

def main():
    print("=" * 50)
    print("  SPACE INVADERS CO-OP CLIENT")
    print("=" * 50)
    mode = input("Mode: [1] Solo  [2] Multiplayer (default: 1): ").strip() or "1"

    net = None
    player_id = 1

    if mode == "2":
        host = input("Server IP (Enter = localhost): ").strip() or "127.0.0.1"
        net = NetworkClient(host)
        print(f"[Client] Connecting to {host}:5555 ...")
        if not net.connect():
            print("[Client] Could not connect. Starting solo instead.")
            net = None
        else:
            print("[Client] Connected! Waiting for Player ID...")
            time.sleep(0.5)
            msgs = net.get_messages()
            for msg in msgs:
                if msg.get("type") == "welcome":
                    player_id = msg.get("player_id", 1)
            print(f"[Client] You are Player {player_id}")

    game = Game(player_id, net)
    if net:
        game.state = "waiting"
    else:
        game.state = "menu"
    game.run()


if __name__ == "__main__":
    main()
