"""
server.py - Space Invaders Co-op WebSocket Server
Designed for Render.com deployment (free tier).

Install: pip install websockets
Run locally: python server.py
"""

import asyncio
import websockets
import json
import random
import time
import os

PORT = int(os.environ.get("PORT", 10000))

# Active rooms: room_code -> {players: {ws: player_id}, state: {...}}
rooms = {}
ws_to_room = {}  # ws -> room_code


def make_room_code():
    import string
    return ''.join(random.choices(string.ascii_uppercase + string.digits, k=5))


def new_room_state():
    return {
        "players": {},       # player_id -> {x, y, lives, score, coins, skin}
        "chat": [],
        "level": 1,
        "started": False,
        "scores": {},
        "coins": {},
    }


async def broadcast_room(room_code, message, exclude=None):
    room = rooms.get(room_code)
    if not room:
        return
    data = json.dumps(message)
    dead = []
    for ws in list(room["players"].keys()):
        if ws == exclude:
            continue
        try:
            await ws.send(data)
        except Exception:
            dead.append(ws)
    for ws in dead:
        await remove_player(ws)


async def send_to(ws, message):
    try:
        await ws.send(json.dumps(message))
    except Exception:
        pass


async def remove_player(ws):
    room_code = ws_to_room.get(ws)
    if not room_code:
        return
    room = rooms.get(room_code)
    if room:
        pid = room["players"].pop(ws, None)
        if pid:
            await broadcast_room(room_code, {"type": "player_left", "player_id": pid})
        if not room["players"]:
            del rooms[room_code]
    ws_to_room.pop(ws, None)


async def handler(ws):
    print(f"[Server] New connection: {ws.remote_address}")
    try:
        async for raw in ws:
            try:
                msg = json.loads(raw)
            except Exception:
                continue

            mtype = msg.get("type")

            # ── Create room ──
            if mtype == "create_room":
                code = make_room_code()
                rooms[code] = new_room_state()
                rooms[code]["players"][ws] = 1
                ws_to_room[ws] = code
                await send_to(ws, {"type": "room_created", "room_code": code, "player_id": 1})
                print(f"[Server] Room {code} created by P1")

            # ── Join room ──
            elif mtype == "join_room":
                code = msg.get("room_code", "").upper().strip()
                room = rooms.get(code)
                if not room:
                    await send_to(ws, {"type": "error", "msg": "Room not found"})
                    continue
                if len(room["players"]) >= 2:
                    await send_to(ws, {"type": "error", "msg": "Room is full"})
                    continue
                room["players"][ws] = 2
                ws_to_room[ws] = code
                await send_to(ws, {"type": "room_joined", "room_code": code, "player_id": 2})
                await broadcast_room(code, {"type": "player_joined", "player_id": 2}, exclude=ws)
                await broadcast_room(code, {"type": "start_game"})
                print(f"[Server] P2 joined room {code}")

            # ── Solo mode ──
            elif mtype == "solo":
                code = make_room_code()
                rooms[code] = new_room_state()
                rooms[code]["players"][ws] = 1
                rooms[code]["solo"] = True
                ws_to_room[ws] = code
                await send_to(ws, {"type": "room_created", "room_code": code, "player_id": 1})
                await send_to(ws, {"type": "start_game"})

            # ── Player state update ──
            elif mtype == "player_update":
                room_code = ws_to_room.get(ws)
                if room_code:
                    room = rooms[room_code]
                    pid = room["players"].get(ws)
                    if pid:
                        room.setdefault("state", {})[str(pid)] = msg.get("data", {})
                        await broadcast_room(room_code, {
                            "type": "player_update",
                            "player_id": pid,
                            "data": msg.get("data", {})
                        }, exclude=ws)

            # ── Chat ──
            elif mtype == "chat":
                room_code = ws_to_room.get(ws)
                if room_code:
                    room = rooms[room_code]
                    pid = room["players"].get(ws, "?")
                    chat_msg = {
                        "type": "chat",
                        "player_id": pid,
                        "text": str(msg.get("text", ""))[:80],
                        "ts": time.time()
                    }
                    await broadcast_room(room_code, chat_msg)

            # ── Relay any other game event ──
            else:
                room_code = ws_to_room.get(ws)
                if room_code:
                    room = rooms[room_code]
                    pid = room["players"].get(ws)
                    msg["from_player"] = pid
                    await broadcast_room(room_code, msg, exclude=ws)

    except websockets.exceptions.ConnectionClosed:
        pass
    finally:
        await remove_player(ws)
        print(f"[Server] Connection closed: {ws.remote_address}")


async def main():
    print(f"[Server] Starting on port {PORT}")
    async with websockets.serve(handler, "0.0.0.0", PORT):
        await asyncio.Future()  # run forever


if __name__ == "__main__":
    asyncio.run(main())
